-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Дек 13 2020 г., 20:14
-- Версия сервера: 10.3.16-MariaDB
-- Версия PHP: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `el_ka_db_pp`
--

-- --------------------------------------------------------

--
-- Структура таблицы `container`
--

CREATE TABLE `container` (
  `id_container` int(11) NOT NULL,
  `Name` varchar(105) CHARACTER SET utf8 NOT NULL,
  `Volume` varchar(15) CHARACTER SET utf8 NOT NULL,
  `type_Sever` tinyint(3) UNSIGNED ZEROFILL DEFAULT 000,
  `type_Kapot` tinyint(3) UNSIGNED ZEROFILL DEFAULT 000,
  `Kolvo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

--
-- Дамп данных таблицы `container`
--

INSERT INTO `container` (`id_container`, `Name`, `Volume`, `type_Sever`, `type_Kapot`, `Kolvo`) VALUES
(17, '', '123,9', 001, 000, 8),
(18, '', '123,9', 001, 000, 8),
(19, '', '12341242,96', 001, 000, 9),
(20, 'hello 2', '3,5', 001, 000, 2);

-- --------------------------------------------------------

--
-- Структура таблицы `containers_street`
--

CREATE TABLE `containers_street` (
  `id_containers_street` int(11) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Volume` varchar(15) NOT NULL,
  `type_kapot` tinyint(3) UNSIGNED ZEROFILL DEFAULT 000,
  `type_koshyx` tinyint(3) UNSIGNED ZEROFILL DEFAULT 000,
  `type_evro_koshyx` tinyint(3) UNSIGNED ZEROFILL DEFAULT 000,
  `Kolvo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `containers_street`
--

INSERT INTO `containers_street` (`id_containers_street`, `Name`, `Volume`, `type_kapot`, `type_koshyx`, `type_evro_koshyx`, `Kolvo`) VALUES
(3, 'Koshyx1', '2312', 000, 001, 000, 2),
(4, 'Evro_Koshyx2', '412', 000, 000, 001, 5),
(5, 'Koshyx1', '2312', 000, 001, 000, 2),
(6, 'Evro_Koshyx2', '412', 000, 000, 001, 5);

-- --------------------------------------------------------

--
-- Структура таблицы `reservoirs`
--

CREATE TABLE `reservoirs` (
  `id_reservoirs` int(11) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Volume` int(11) NOT NULL,
  `Pump` tinyint(3) UNSIGNED ZEROFILL DEFAULT 000,
  `Heat` tinyint(3) UNSIGNED ZEROFILL DEFAULT 000,
  `Heater` tinyint(3) UNSIGNED ZEROFILL DEFAULT 000,
  `Emergency_drain` tinyint(3) UNSIGNED ZEROFILL DEFAULT 000,
  `Kolvo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `reservoirs`
--

INSERT INTO `reservoirs` (`id_reservoirs`, `Name`, `Volume`, `Pump`, `Heat`, `Heater`, `Emergency_drain`, `Kolvo`) VALUES
(4, 'Perviy', 12, 001, 001, 000, 001, 4),
(5, 'Vtoroy', 199, 000, 001, 001, 001, 5),
(6, 'Perviy', 12, 001, 001, 000, 001, 4),
(7, 'Vtoroy', 199, 000, 001, 001, 001, 5);

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id_users` int(11) NOT NULL,
  `login` varchar(15) NOT NULL,
  `password` varchar(15) NOT NULL,
  `role` varchar(15) NOT NULL,
  `FIO` varchar(110) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id_users`, `login`, `password`, `role`, `FIO`) VALUES
(1, 'test1', '123', 'Admin', ''),
(2, 'test2', '123', 'User', 'fts_korin@bk.ru'),
(5, 'test3', '123', 'User', 'fts_tesla@bk.ru'),
(7, 'testtrue', '123456789', 'Admin', 'Ne Shestipalov');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `container`
--
ALTER TABLE `container`
  ADD PRIMARY KEY (`id_container`);

--
-- Индексы таблицы `containers_street`
--
ALTER TABLE `containers_street`
  ADD PRIMARY KEY (`id_containers_street`);

--
-- Индексы таблицы `reservoirs`
--
ALTER TABLE `reservoirs`
  ADD PRIMARY KEY (`id_reservoirs`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_users`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `container`
--
ALTER TABLE `container`
  MODIFY `id_container` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT для таблицы `containers_street`
--
ALTER TABLE `containers_street`
  MODIFY `id_containers_street` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `reservoirs`
--
ALTER TABLE `reservoirs`
  MODIFY `id_reservoirs` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id_users` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
